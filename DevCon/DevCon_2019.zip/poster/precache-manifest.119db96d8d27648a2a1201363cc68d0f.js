self.__precacheManifest = [
  {
    "revision": "db9601a60aa2e312a8a474867a2258f5",
    "url": "./static/media/poster-back.db9601a6.jpg"
  },
  {
    "revision": "61fd0d067e7dc75d577cff9f8e447faf",
    "url": "./static/media/logo_2x.61fd0d06.png"
  },
  {
    "revision": "c60616bd12c102e4cf9e8ff4f911358b",
    "url": "./static/media/ganapathy-kumar-113604-unsplash.c60616bd.jpg"
  },
  {
    "revision": "664d7de2be293a7b1322e94a10fe9199",
    "url": "./static/media/download.664d7de2.ico"
  },
  {
    "revision": "4a686d48d5a089750c49",
    "url": "./static/js/runtime~main.4a686d48.js"
  },
  {
    "revision": "f11dd5cd37a98887b1c1",
    "url": "./static/js/main.f11dd5cd.chunk.js"
  },
  {
    "revision": "c24d2e056a0413496de7",
    "url": "./static/js/1.c24d2e05.chunk.js"
  },
  {
    "revision": "f11dd5cd37a98887b1c1",
    "url": "./static/css/main.c72e57e6.chunk.css"
  },
  {
    "revision": "2d55b27a1297b6c98ab884b776f16c7a",
    "url": "./index.html"
  }
];